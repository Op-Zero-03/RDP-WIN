Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' -Name 'fSingleSessionPerUser' -Value 0
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' -Name 'MaxInstanceCount' -Value 900
Import-Module ServerManager
Add-WindowsFeature RDS-RD-Server
Add-WindowsFeature RDS-Licensing
